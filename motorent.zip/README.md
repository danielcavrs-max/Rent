# MotoRent 2.0

Asistente de rentabilidad para conductores de moto. Estado actual: Etapa 2 (proyecto base que compila).

## Compilar desde el teléfono
1. En GitHub crea un repositorio nuevo.
2. Add file > Create new file, nombre `.github/workflows/build.yml`, pega el contenido del workflow y haz Commit.
3. Add file > Upload files, sube `motorent.zip` y haz Commit.
4. Pestaña Actions > "Compilar APK" > espera el check verde.
5. Abre la ejecución, baja a Artifacts y descarga `MotoRent-debug-apk` (es un .zip que contiene el .apk).
6. Extrae el .apk e instálalo (permite instalar apps desconocidas).

Versiones fijas: Gradle 8.7, AGP 8.5.2, Kotlin 1.9.24, JDK 17, compileSdk 34, targetSdk 33, minSdk 26.
