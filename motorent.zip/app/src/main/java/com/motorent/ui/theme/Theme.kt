package com.motorent.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val EstadoVerde = Color(0xFF2ECC71)
val EstadoRojo = Color(0xFFE74C3C)
val EstadoAmarillo = Color(0xFFF1C40F)
val EstadoGris = Color(0xFF8A9099)

private val EsquemaOscuro = darkColorScheme(
    primary = EstadoVerde,
    onPrimary = Color.Black,
    background = Color(0xFF0E0F11),
    onBackground = Color(0xFFEDEFF2),
    surface = Color(0xFF17191D),
    onSurface = Color(0xFFEDEFF2),
    surfaceVariant = Color(0xFF1F2227),
    onSurfaceVariant = Color(0xFFB4BAC2),
    error = EstadoRojo
)

@Composable
fun MotoRentTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = EsquemaOscuro, content = content)
}
