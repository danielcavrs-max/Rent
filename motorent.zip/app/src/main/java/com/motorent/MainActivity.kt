package com.motorent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.motorent.ui.theme.EstadoGris
import com.motorent.ui.theme.MotoRentTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MotoRentTheme {
                MotoRentApp()
            }
        }
    }
}

enum class Pantalla(val titulo: String, val icono: ImageVector, val etapa: Int) {
    INICIO("Inicio", Icons.Filled.Home, 2),
    FILTROS("Filtros", Icons.Filled.Settings, 5),
    EN_VIVO("En vivo", Icons.Filled.PlayArrow, 6),
    HISTORIAL("Historial", Icons.Filled.DateRange, 6),
    PERMISOS("Permisos", Icons.Filled.Lock, 3)
}

@Composable
fun MotoRentApp() {
    var actual by remember { mutableStateOf(Pantalla.INICIO) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                Pantalla.values().forEach { p ->
                    NavigationBarItem(
                        selected = p == actual,
                        onClick = { actual = p },
                        icon = { Icon(p.icono, contentDescription = p.titulo) },
                        label = { Text(p.titulo, maxLines = 1) }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            Text(
                text = actual.titulo,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(16.dp))
            if (actual == Pantalla.INICIO) {
                Inicio()
            } else {
                Pendiente(actual)
            }
        }
    }
}

@Composable
private fun Tarjeta(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            content()
        }
    }
}

@Composable
private fun Inicio() {
    Tarjeta {
        Text("Estado del servicio", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(4.dp))
        Text(
            "Detenido",
            style = MaterialTheme.typography.titleLarge,
            color = EstadoGris
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Versión base (Etapa 2). Todavía no existe captura de pantalla ni OCR.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
    Spacer(Modifier.height(16.dp))
    Button(
        onClick = { },
        enabled = false,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("INICIAR ANÁLISIS (Etapa 3)")
    }
}

@Composable
private fun Pendiente(pantalla: Pantalla) {
    Tarjeta {
        Text(
            "Esta sección todavía no está implementada. Se construye en la Etapa ${pantalla.etapa}.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
